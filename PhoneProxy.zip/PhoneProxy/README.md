# PhoneProxy（无扩展版，含 UDP）

把 iPhone 的蜂窝流量变成 SOCKS5 出口（TCP + UDP）：手机**主动**用 SSH 连到你的 Ubuntu VPS，
建立与 `ssh -R 127.0.0.1:11081:...` 等效的反向转发。VPS 上只有 `127.0.0.1:11080` 对本机程序开放。

```
VPS 上的程序(xray 等)
   │ SOCKS5 (TCP CONNECT / UDP ASSOCIATE, 账号密码)
   ▼
VPS 127.0.0.1:11080  ← vps/front.py（前置程序）
   │ TCP 连接；UDP 数据报被封装成帧，走同一条 TCP
   ▼
VPS 127.0.0.1:11081  ══ SSH 反向转发 ══▶  iPhone SOCKS5(回环, 账号密码)
                                           ├─ TCP → 蜂窝 → 互联网
                                           └─ UDP → 蜂窝 → 互联网
```

SSH 只能转发 TCP，所以 UDP 无法直接转发；做法是 VPS 端的 `front.py` 在本机开 UDP 端口，
把数据报封装成 `[2字节长度][ATYP][地址][端口][负载]` 的帧，经 TCP 隧道交给手机，手机再从蜂窝发出 UDP，回包按同样格式送回。

## 结构

| 部分 | 说明 |
|---|---|
| `App/` | SwiftUI 界面、钥匙串存储、静音音频保活、图标 |
| `Core/SSHReverseTunnel` | libssh2 反向转发、心跳、主机指纹校验、自动重连 |
| `Core/Socks5Server` | 手机本机回环 SOCKS5：账号密码认证、TCP CONNECT、私有命令 0x80（UDP-over-TCP）；出站强制蜂窝 |
| `Core/ProxyCore` | 网络路径监控：Wi‑Fi/蜂窝切换时打断旧连接并重连 |
| `vps/front.py` | VPS 前置程序：对外标准 SOCKS5（含 UDP ASSOCIATE），对内转给手机 |
| `project.yml` | XcodeGen 配置 |

## 端口约定

| 端口 | 位置 | 用途 |
|---|---|---|
| **11081** | VPS 127.0.0.1 | App 里「VPS 监听端口」填这个，SSH 反向转发落点（内部用） |
| **11080** | VPS 127.0.0.1 | `front.py` 对外端口，你的程序连这个 |

SOCKS5 用户名/密码在 App 和 VPS 的 `front.py` 里必须一致。

## UDP 说明与限制

- 每个目的地址一个出站 UDP 连接（强制蜂窝），空闲 60 秒回收，单会话最多 256 个。
- 回包的来源地址按请求的目的地址返回（不是完全锥形 NAT），对 DNS、QUIC、游戏、WebRTC 等常见场景够用。
- 不支持 UDP 分片（FRAG≠0 的包会被丢弃）。
- UDP 走 TCP 隧道，会有 TCP 队头阻塞：丢包/切网时延迟抖动比原生 UDP 大。

## 签名

本版本不需要任何特殊权限（没有 Network Extension、没有 entitlements）。
任何普通的 `.p12` + `.mobileprovision`（包括通配符描述文件）都可以重签，Bundle ID 可随意改。

## VPS 端（Ubuntu，OpenSSH ≥ 7.8）

1. sshd 心跳（网络切换后尽快清理旧连接，避免端口被残留会话占用）：
   `/etc/ssh/sshd_config.d/phoneproxy.conf`
   ```
   ClientAliveInterval 10
   ClientAliveCountMax 2
   ```
   然后 `sudo systemctl reload ssh`。保持 `GatewayPorts no`（默认）。
2. 如使用密钥登录，可在 `authorized_keys` 限制该密钥只能反向监听 11081：
   ```
   restrict,port-forwarding,permitlisten="127.0.0.1:11081" ssh-ed25519 AAAA... phoneproxy
   ```
3. 安装 `front.py` 并设为 systemd 服务（见聊天里的粘贴命令），环境变量：
   `SOCKS_USER`、`SOCKS_PASS`（必填）、`LISTEN_PORT`(11080)、`UPSTREAM_PORT`(11081)。
4. 测试 TCP：`curl -x socks5h://用户名:密码@127.0.0.1:11080 https://ifconfig.me`

## 使用与注意

- 后台保活靠循环播放静音音频（UIBackgroundModes=audio）。**不要在后台划掉 App**；
  iOS 偶尔仍会杀进程，打开 App 会自动恢复运行（可在选项里关闭）。
- 在「设置 → 蜂窝网络」里给 PhoneProxy 开启蜂窝数据，并关闭低数据模式。
- 若手机上同时开着小火箭等代理 App，要让 VPS 的 IP 走直连，否则 SSH 连接会被绕回隧道里。
- 首次连接后点「固定当前连接的指纹」。
- libssh2 预编译包使用 OpenSSL 1.1.1w（上游已停止维护），仅用于连接你自己的服务器。
