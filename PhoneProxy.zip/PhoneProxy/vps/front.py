#!/usr/bin/env python3
"""PhoneProxy VPS 前置程序（仅依赖 Python 3.8+ 标准库）。

对外：127.0.0.1:LISTEN_PORT（默认 11080），标准 SOCKS5，用户名/密码认证，支持 CONNECT 和 UDP ASSOCIATE。
对内：把请求转给手机经 SSH 反向转发过来的 127.0.0.1:UPSTREAM_PORT（默认 11081）。
  - CONNECT       -> 向手机发 SOCKS5 CONNECT
  - UDP ASSOCIATE -> 在 VPS 本机开一个 UDP 端口，把数据报封装成帧，经同一条 TCP 隧道交给手机（私有命令 0x80）

帧格式（两个方向相同）： [2 字节长度 N][ATYP][地址][2 字节端口][UDP 负载]
"""
import asyncio
import hmac
import os
import struct
import sys

LISTEN = ("127.0.0.1", int(os.environ.get("LISTEN_PORT", "11080")))
UPSTREAM = ("127.0.0.1", int(os.environ.get("UPSTREAM_PORT", "11081")))
USER = os.environ["SOCKS_USER"].encode()
PASS = os.environ["SOCKS_PASS"].encode()
MAX_WBUF = 1 << 20


def log(*a):
    print(*a, file=sys.stderr, flush=True)


async def read_addr(r, atyp):
    """读取 ATYP 之后的地址+端口，返回原始字节（不含 ATYP）。"""
    if atyp == 1:
        return await r.readexactly(4 + 2)
    if atyp == 3:
        ln = await r.readexactly(1)
        return ln + await r.readexactly(ln[0] + 2)
    if atyp == 4:
        return await r.readexactly(16 + 2)
    raise ValueError("bad atyp")


async def open_upstream():
    r, w = await asyncio.wait_for(asyncio.open_connection(*UPSTREAM), 10)
    w.write(b"\x05\x01\x02")
    if await asyncio.wait_for(r.readexactly(2), 10) != b"\x05\x02":
        raise ConnectionError("upstream method")
    w.write(b"\x01" + bytes([len(USER)]) + USER + bytes([len(PASS)]) + PASS)
    if await asyncio.wait_for(r.readexactly(2), 10) != b"\x01\x00":
        raise ConnectionError("upstream auth")
    return r, w


async def read_reply(r):
    hdr = await asyncio.wait_for(r.readexactly(4), 15)
    rest = await read_addr(r, hdr[3])
    return hdr, rest


async def pipe(r, w):
    try:
        while True:
            d = await r.read(65536)
            if not d:
                break
            w.write(d)
            await w.drain()
    except Exception:
        pass
    finally:
        try:
            w.close()
        except Exception:
            pass


def fail(w, code):
    try:
        w.write(bytes([5, code, 0, 1, 0, 0, 0, 0, 0, 0]))
    except Exception:
        pass


class UDPRelay(asyncio.DatagramProtocol):
    def __init__(self, up_writer):
        self.up = up_writer
        self.client = None
        self.transport = None

    def connection_made(self, t):
        self.transport = t

    def datagram_received(self, data, addr):
        if addr[0] != "127.0.0.1":
            return
        if self.client is None:
            self.client = addr
        elif addr != self.client:
            return
        # RSV(2) FRAG(1) ATYP ADDR PORT DATA
        if len(data) < 10 or data[2] != 0:
            return
        body = data[3:]
        if len(body) > 65535:
            return
        if self.up.transport.get_write_buffer_size() > MAX_WBUF:
            return  # 拥塞时丢包
        self.up.write(struct.pack(">H", len(body)) + body)


async def handle(cr, cw):
    up_w = None
    udp_t = None
    try:
        # 1. 方法协商
        ver, n = await asyncio.wait_for(cr.readexactly(2), 15)
        if ver != 5:
            return
        methods = await cr.readexactly(n)
        if 2 not in methods:
            cw.write(b"\x05\xff")
            return
        cw.write(b"\x05\x02")

        # 2. 用户名/密码
        v, ul = struct.unpack("BB", await asyncio.wait_for(cr.readexactly(2), 15))
        u = await cr.readexactly(ul)
        pl = (await cr.readexactly(1))[0]
        p = await cr.readexactly(pl)
        ok = hmac.compare_digest(u, USER) & hmac.compare_digest(p, PASS)
        if v != 1 or not ok:
            await asyncio.sleep(1)
            cw.write(b"\x01\x01")
            return
        cw.write(b"\x01\x00")

        # 3. 请求
        h = await asyncio.wait_for(cr.readexactly(4), 15)
        if h[0] != 5:
            return
        addr = await read_addr(cr, h[3])
        cmd = h[1]

        if cmd == 1:  # CONNECT
            try:
                ur, up_w = await open_upstream()
                up_w.write(b"\x05\x01\x00" + bytes([h[3]]) + addr)
                hdr, rest = await read_reply(ur)
            except Exception as e:
                log("connect upstream failed:", repr(e))
                fail(cw, 0x01)
                return
            cw.write(hdr + rest)
            if hdr[1] != 0:
                return
            await asyncio.gather(pipe(cr, up_w), pipe(ur, cw))

        elif cmd == 3:  # UDP ASSOCIATE
            try:
                ur, up_w = await open_upstream()
                up_w.write(b"\x05\x80\x00\x01\x00\x00\x00\x00\x00\x00")
                hdr, rest = await read_reply(ur)
                if hdr[1] != 0:
                    raise ConnectionError("upstream refused UoT, rep=%d" % hdr[1])
            except Exception as e:
                log("udp upstream failed:", repr(e))
                fail(cw, 0x01)
                return

            loop = asyncio.get_running_loop()
            relay = UDPRelay(up_w)
            udp_t, _ = await loop.create_datagram_endpoint(
                lambda: relay, local_addr=("127.0.0.1", 0))
            port = udp_t.get_extra_info("sockname")[1]
            cw.write(b"\x05\x00\x00\x01\x7f\x00\x00\x01" + struct.pack(">H", port))
            await cw.drain()

            async def up_to_client():
                try:
                    while True:
                        n = struct.unpack(">H", await ur.readexactly(2))[0]
                        body = await ur.readexactly(n)
                        if relay.client is not None:
                            udp_t.sendto(b"\x00\x00\x00" + body, relay.client)
                except Exception:
                    pass

            async def wait_client_close():
                try:
                    while await cr.read(1024):
                        pass
                except Exception:
                    pass

            t1 = asyncio.ensure_future(up_to_client())
            t2 = asyncio.ensure_future(wait_client_close())
            await asyncio.wait([t1, t2], return_when=asyncio.FIRST_COMPLETED)
            t1.cancel()
            t2.cancel()
        else:
            fail(cw, 0x07)
    except Exception:
        pass
    finally:
        if udp_t is not None:
            udp_t.close()
        for w in (up_w, cw):
            if w is not None:
                try:
                    w.close()
                except Exception:
                    pass


async def main():
    server = await asyncio.start_server(handle, *LISTEN)
    log("listening on %s:%d -> upstream %s:%d" % (LISTEN + UPSTREAM))
    async with server:
        await server.serve_forever()


if __name__ == "__main__":
    asyncio.run(main())
